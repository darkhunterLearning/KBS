from django.apps import AppConfig


class AudioRecorderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'audio_recorder'
